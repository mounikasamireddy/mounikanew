#
# Cookbook:: build_cookbook
# Recipe:: smoke
#
# Copyright:: 2018, The Authors, All Rights Reserved.
include_recipe 'delivery-truck::smoke'
